from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.


def index(request):
    return HttpResponse('hello World')


def new(request):
    return HttpResponse('you did it !!')


def test(request):
    return HttpResponse('Hey I nailed it this time')
